<?php
/* Template Name: Home Page */

//  Advanced Custom Fields
get_header();
get_template_part('template-parts/content', 'homeheader');
get_template_part('template-parts/content', 'mainContent');
// the_content();
get_footer();
?>